﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using MySql.Data.MySqlClient;

namespace ytrewq
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

            string lg = textBox1.Text;
            string psw = textBox2.Text;

            string connStr = "server=localhost;user=root;database=test1bank;password=;";
            MySqlConnection conn = new MySqlConnection(connStr);

            conn.Open();
            string sql1 = "SELECT name FROM user WHERE login = " + textBox1.Text;
            string sql2 = "SELECT name FROM user WHERE password = "+"\""+textBox2.Text+"\"";

            MySqlCommand command = new MySqlCommand(sql1, conn);
            MySqlCommand command2 = new MySqlCommand(sql2, conn);

            string name = command.ExecuteScalar().ToString();
            string name2 = command2.ExecuteScalar().ToString();

            string sql3 = "SELECT iduser FROM user WHERE login = " + textBox1.Text;
            string sql4 = "SELECT iduser FROM user WHERE password = " + "\"" + textBox2.Text + "\"";

            MySqlCommand command3 = new MySqlCommand(sql3, conn);
            MySqlCommand command4 = new MySqlCommand(sql4, conn);

            string id1 = command3.ExecuteScalar().ToString();
            string id2 = command4.ExecuteScalar().ToString();

            if (id1 == id2)
            {
                MessageBox.Show("welcome");
            }
            else MessageBox.Show("Wrong login or password");
            label4.Text = name2;
            
            conn.Close();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ytrewq
{
    public partial class Form2 : Form
    {
        ulong sum1;
        uint sum2;
        ulong sum3;

        public Form2()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

            //Стабильный
            ulong P = Convert.ToUInt64(trackBar1.Value);
            ulong t = Convert.ToUInt64(trackBar2.Value);
            uint T = 365;
            uint i = 8;
            //ulong sum1;
            sum1 = (P * i * t) / (T * 100);
            label11.Text = string.Format("{0}", sum1);

            //Оптимальный
            ulong PMT = Convert.ToUInt64(trackBar3.Value);
            double N = Convert.ToDouble(trackBar2.Value) / 365;
            double I = 0.05;
            uint M = 1;
            //int sum2;
            double Z = 1 + I / M;
            double MP = Convert.ToDouble(Math.Pow(Z, N));
            sum2 = Convert.ToUInt32((PMT * (M / I) * (MP - 1) + P * MP) - P);
            label12.Text = String.Format("{0}", sum2);

            //Стандарт
            ulong pmt = Convert.ToUInt64(trackBar3.Value);
            double n = Convert.ToDouble(trackBar2.Value) / 365;
            double ii = 0.06;
            uint m = 1;
            //double sum3;
            double z = 1 + ii / m;
            double mp = Convert.ToDouble(Math.Pow(z, n));
            sum3 = Convert.ToUInt64((PMT * (m / ii) * (mp - 1) + P * mp) - P);
            label13.Text = String.Format("{0}", sum3);
            //Создание формы 3
            Form3 frm3 = new Form3();
            frm3.Show();
            this.Hide();
            
            frm3.label6.Text = this.label11.Text;
            frm3.label10.Text = this.label12.Text;
            frm3.label14.Text = this.label13.Text;

            Convert.ToUInt32(P);

            ulong a1 = sum1 + P;
            uint a2 = Convert.ToUInt32(sum2 + P);
            ulong a3 = sum3 + P;

            frm3.label7.Text = String.Format("{0}", a1);
            frm3.label11.Text = String.Format("{0}", a2);
            frm3.label15.Text = String.Format("{0}", a3);
        }

        private void trackBar1_Scroll(object sender, EventArgs e)
        {
            textBox1.Text = String.Format("{0:d}",trackBar1.Value);
            
            //Стабильный
            ulong P = Convert.ToUInt64(trackBar1.Value);
            ulong t = Convert.ToUInt64(trackBar2.Value);
            uint T = 365;
            uint i = 8;
           //ulong sum1;
            sum1 = (P * i * t) / (T * 100);
            label11.Text = string.Format("{0}", sum1);

            //Оптимальный
            ulong PMT = Convert.ToUInt64(trackBar3.Value);
            double N = Convert.ToDouble(trackBar2.Value)/365;
            double I = 0.05;
            uint M = 1;
            //int sum2;
            double Z = 1 + I / M;
            double MP = Convert.ToDouble(Math.Pow(Z,N));
            sum2 = Convert.ToUInt32((PMT * (M / I) * (MP - 1) + P * MP) - P);
            label12.Text = String.Format("{0}", sum2);

            //Стандарт
            ulong pmt = Convert.ToUInt64(trackBar3.Value);
            double n = Convert.ToDouble(trackBar2.Value) / 365;
            double ii = 0.06;
            uint m = 1;
           //double sum3;
            double z = 1 + ii / m;
            double mp = Convert.ToDouble(Math.Pow(z, n));
            sum3 = Convert.ToUInt32((PMT * (m / ii) * (mp - 1) + P * mp) - P);
            label13.Text = String.Format("{0}", sum3);

        }

        private void trackBar2_Scroll(object sender, EventArgs e)
        {
            textBox2.Text = String.Format("{0:d}",trackBar2.Value);

            //Стабильный
            ulong P = Convert.ToUInt64(trackBar1.Value);
            ulong t = Convert.ToUInt64(trackBar2.Value);
            uint T = 365;
            uint i = 8;
            //ulong sum1;
            sum1 = (P * i * t) / (T * 100);
            label11.Text = string.Format("{0}", sum1);

            //Оптимальный
            ulong PMT = Convert.ToUInt64(trackBar3.Value);
            double N = Convert.ToDouble(trackBar2.Value) / 365;
            double I = 0.05;
            uint M = 1;
            //int sum2;
            double Z = 1 + I / M;
            double MP = Convert.ToDouble(Math.Pow(Z, N));
            sum2 = Convert.ToUInt32((PMT * (M / I) * (MP - 1) + P * MP) - P);
            label12.Text = String.Format("{0}", sum2);

            //Стандарт
            ulong pmt = Convert.ToUInt64(trackBar3.Value);
            double n = Convert.ToDouble(trackBar2.Value) / 365;
            double ii = 0.06;
            uint m = 1;
            //double sum3;
            double z = 1 + ii / m;
            double mp = Convert.ToDouble(Math.Pow(z, n));
            sum3 = Convert.ToUInt32((PMT * (m / ii) * (mp - 1) + P * mp) - P);
            label13.Text = String.Format("{0}", sum3);
        }

        private void trackBar3_Scroll(object sender, EventArgs e)
        {
            textBox3.Text = String.Format("{0:d}", trackBar3.Value);

            //Стабильный
            ulong P = Convert.ToUInt64(trackBar1.Value);
            ulong t = Convert.ToUInt64(trackBar2.Value);
            uint T = 365;
            uint i = 8;
            //ulong sum1;
            sum1 = (P * i * t) / (T * 100);
            label11.Text = string.Format("{0}", sum1);

            //Оптимальный
            ulong PMT = Convert.ToUInt64(trackBar3.Value);
            double N = Convert.ToDouble(trackBar2.Value) / 365;
            double I = 0.05;
            uint M = 1;
            //int sum2;
            double Z = 1 + I / M;
            double MP = Convert.ToDouble(Math.Pow(Z, N));
            sum2 = Convert.ToUInt32((PMT * (M / I) * (MP - 1) + P * MP) - P);
            label12.Text = String.Format("{0}", sum2);

            //Стандарт
            ulong pmt = Convert.ToUInt64(trackBar3.Value);
            double n = Convert.ToDouble(trackBar2.Value) / 365;
            double ii = 0.06;
            uint m = 1;
            //double sum3;
            double z = 1 + ii / m;
            double mp = Convert.ToDouble(Math.Pow(z, n));
            sum3 = Convert.ToUInt32((PMT * (m / ii) * (mp - 1) + P * mp) - P);
            label13.Text = String.Format("{0}", sum3);
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            if (textBox1.Text.Equals(""))
            {
                textBox1.Text = "0";
            }
            if((Convert.ToInt32(textBox1.Text)<=10000000) && (Convert.ToInt32(textBox1.Text)>=1000))
            {
                
                trackBar1.Value = Convert.ToInt32(textBox1.Text);

                //Стабильный
                ulong P = Convert.ToUInt64(trackBar1.Value);
                ulong t = Convert.ToUInt64(trackBar2.Value);
                uint T = 365;
                uint i = 8;
                //ulong sum1;
                sum1 = (P * i * t) / (T * 100);
                label11.Text = string.Format("{0}", sum1);

                //Оптимальный
                ulong PMT = Convert.ToUInt64(trackBar3.Value);
                double N = Convert.ToDouble(trackBar2.Value) / 365;
                double I = 0.05;
                uint M = 1;
                //int sum2;
                double Z = 1 + I / M;
                double MP = Convert.ToDouble(Math.Pow(Z, N));
                sum2 = Convert.ToUInt32((PMT * (M / I) * (MP - 1) + P * MP) - P);
                label12.Text = String.Format("{0}", sum2);

                //Стандарт
                ulong pmt = Convert.ToUInt64(trackBar3.Value);
                double n = Convert.ToDouble(trackBar2.Value) / 365;
                double ii = 0.06;
                uint m = 1;
                //double sum3;
                double z = 1 + ii / m;
                double mp = Convert.ToDouble(Math.Pow(z, n));
                sum3 = Convert.ToUInt32((PMT * (m / ii) * (mp - 1) + P * mp) - P);
                label13.Text = String.Format("{0}", sum3);                
            }
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            if (textBox2.Text.Equals(""))
            {
                textBox2.Text = "0";
            }
            if ((Convert.ToInt32(textBox2.Text) <= 1825) && (Convert.ToInt32(textBox2.Text) >= 90))
            {
                trackBar2.Value = Convert.ToInt32(textBox2.Text);

                //Стабильный
                ulong P = Convert.ToUInt64(trackBar1.Value);
                ulong t = Convert.ToUInt64(trackBar2.Value);
                uint T = 365;
                uint i = 8;
                //ulong sum1;
                sum1 = (P * i * t) / (T * 100);
                label11.Text = string.Format("{0}", sum1);

                //Оптимальный
                ulong PMT = Convert.ToUInt64(trackBar3.Value);
                double N = Convert.ToDouble(trackBar2.Value) / 365;
                double I = 0.05;
                uint M = 1;
                //int sum2;
                double Z = 1 + I / M;
                double MP = Convert.ToDouble(Math.Pow(Z, N));
                sum2 = Convert.ToUInt32((PMT * (M / I) * (MP - 1) + P * MP) - P);
                label12.Text = String.Format("{0}", sum2);

                //Стандарт
                ulong pmt = Convert.ToUInt64(trackBar3.Value);
                double n = Convert.ToDouble(trackBar2.Value) / 365;
                double ii = 0.06;
                uint m = 1;
                //double sum3;
                double z = 1 + ii / m;
                double mp = Convert.ToDouble(Math.Pow(z, n));
                sum3 = Convert.ToUInt32((PMT * (m / ii) * (mp - 1) + P * mp) - P);
                label13.Text = String.Format("{0}", sum3);
            }
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
            if (textBox3.Text.Equals(""))
            {
                textBox3.Text = "0";
            }
            if ((Convert.ToInt32(textBox3.Text) <= 1000000) && (Convert.ToInt32(textBox3.Text) >= 0))
            {
                trackBar3.Value = Convert.ToInt32(textBox3.Text);

                //Стабильный
                ulong P = Convert.ToUInt64(trackBar1.Value);
                ulong t = Convert.ToUInt64(trackBar2.Value);
                uint T = 365;
                uint i = 8;
                //ulong sum1;
                sum1 = (P * i * t) / (T * 100);
                label11.Text = string.Format("{0}", sum1);

                //Оптимальный
                ulong PMT = Convert.ToUInt64(trackBar3.Value);
                double N = Convert.ToDouble(trackBar2.Value) / 365;
                double I = 0.05;
                uint M = 1;
                //int sum2;
                double Z = 1 + I / M;
                double MP = Convert.ToDouble(Math.Pow(Z, N));
                sum2 = Convert.ToUInt32((PMT * (M / I) * (MP - 1) + P * MP) - P);
                label12.Text = String.Format("{0}", sum2);

                //Стандарт
                ulong pmt = Convert.ToUInt64(trackBar3.Value);
                double n = Convert.ToDouble(trackBar2.Value) / 365;
                double ii = 0.06;
                uint m = 1;
                //double sum3;
                double z = 1 + ii / m;
                double mp = Convert.ToDouble(Math.Pow(z, n));
                sum3 = Convert.ToUInt32((PMT * (m / ii) * (mp - 1) + P * mp) - P);
                label13.Text = String.Format("{0}", sum3);
            }
        } 
    }
}
